import sys

if __name__ == "__main__":
    from ._cli import main
    sys.exit(main())